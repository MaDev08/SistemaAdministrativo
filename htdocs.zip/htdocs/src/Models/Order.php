<?php 

require_once "src/Models/Model.php";

class Order extends Model {

    protected $tableName = 'pedidos';

    
}